<template>
    <div class="navbar">
        <nav class="nav-extended">
            <img src="../assets/CompanyLogo.png"/>
        </nav>    
    </div>
</template>

<script>
import db from '@/firebase/init'
export default {
    name: 'Navbar',
    data(){
        return {
            posts: [
                // { subject: 'Hackathon Announcement', slug: 'hackathon-announcement', author: 'Derick Lee', date: 'July 7, 2020', message: 'A reminder for fellows to come to our Hackathon this Friday!', id: '1'},
                // { subject: 'PilotCity Videoask Announcement', slug: 'pilotcity-videoask-announcement', author: 'Kenny Bo', date: 'July 8, 2020', message: 'Make sure to answer the videoask question by Friday!', id: '2'}
            ],
            searchTerm: ''
        }
    },
    methods: {

    },
    created(){
        //fetch data from firestore
        db.collection('posts').get()
        .then(snapshot => {
            snapshot.forEach(doc => {
                let post = doc.data()
                post.id = doc.id
                this.posts.push(post)
            })
        })    
    }
}
</script>

<style>
nav.nav-extended {
    position: absolute;
    left: 0px;
    right: 0px;
    top: 0px;
    background: #4F4F4F;
    height: 4em;
}
img {
    position: absolute;
    left: 60px;
    top: 10px;
    object-fit: cover;
    height: 40px;
}
</style>