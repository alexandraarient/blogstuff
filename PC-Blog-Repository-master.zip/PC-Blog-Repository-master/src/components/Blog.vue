<template>
    <div class="blog">
      <svg width="270" height="40">
        <rect width="413" height="70" style="fill:rgb(196,196,196)" />                  
      </svg> 
      <input class="searchbar" type="text" v-model="searchTerm"> 
      <i class="material-icons search">search</i>
      <i class="material-icons menu">menu</i>
      <!-- <div class="triangle-with-shadow"></div> -->
        <br/>
        <h2>PilotCity Social Network</h2>
        <!-- <div id="rectangle"></div> -->
        <div class="blog container">
            <div class="card" v-for="post in filteredPosts" :key="post.id">
                <div class="card-content">
                    <h3><br>{{ post.author }}: {{ post.subject }}</h3>
                    <h4>{{ post.time }}<br>{{ post.date }}</h4>
                    <p>{{ post.message }}</p>
                    <a href="" class="btn-floating btn-small">
                      <router-link :to="{ name:'EditPost',params:{ post_slug: post.slug }}">
                        <i class="material-icons create">create</i>
                      </router-link>
                </a>
                </div>
            </div>
        </div>
        <br/>
        <br/>
        <a href="" class="btn-floating btn-large halfway-fab">
          <router-link :to="{ name: 'AddPost' }">
            <i class="material-icons add">add</i>
          </router-link>
        </a>
    </div>
</template>

<script>
import db from '@/firebase/init'

export default {
    name: 'Blog',
    data(){
        return {
            posts: [
                // { subject: 'Hackathon Announcement', slug: 'hackathon-announcement', author: 'Derick Lee', date: 'July 7, 2020', message: 'A reminder for fellows to come to our Hackathon this Friday!', id: '1'},
                // { subject: 'PilotCity Videoask Announcement', slug: 'pilotcity-videoask-announcement', author: 'Kenny Bo', date: 'July 8, 2020', message: 'Make sure to answer the videoask question by Friday!', id: '2'}
            ],
            searchTerm: ''
        }
    },
    methods: {

    },
    computed: {
        filteredPosts(){
            return this.posts.filter(post => {
                return post.message.match(this.searchTerm) || post.date.match(this.searchTerm) || post.subject.match(this.searchTerm) || post.author.match(this.searchTerm) || post.time.match(this.searchTerm)
            })
        }
    },
    created(){
        //fetch data from firestore
        db.collection('posts').get()
        .then(snapshot => {
            snapshot.forEach(doc => {
                let post = doc.data()
                post.id = doc.id
                this.posts.push(post)
            })
        })    
    }
}
</script>


<style>
h2 {
  text-align: center;
  font-family: 'Raleway', sans-serif;
  font-size: 30px;
  color: rgba(79, 79, 79, 0.86);
  font-weight: 800;
}
h3 {
  font-family: 'Raleway', sans-serif;
  font-size: 20px;
  color: #000000;
  font-weight: 300;
}
h4 {
  position: absolute;
  top: 0px;
  bottom: 100px;
  left: 26px;
  font-family: 'Raleway', sans-serif;
  /* font-size: 16px;
  color: rgba(79, 79, 79, 0.86);
  font-weight: lighter; */
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 1px;
  color: rgba(79, 79, 79, 0.86);
}
p {
  text-align: left;
  font-family: 'Raleway', sans-serif;
  font-style: lighter;
  font-size: 18px;
  font-weight: 50;
  color: #000000;
  font-weight: lighter;
}
.container {
  width: 60%;
  height: 40%;
  background: #FFFF;
  /* box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25); */
  /* border: 1px solid #000000; */
  left: 80px;
  right: 80px;
  top: 200px;
  bottom: 50px;
  padding-right:50px;
  padding-left:50px;
  padding-top:10px;
  padding-bottom:10px;
}
.card {
  position: relative;
}
/* .btn-floating {
    background-color: #C4C4C4;
} */
/* .btn {
   position: absolute;
   background-color: #C4C4C4;
   bottom: 200px;
   right: 200px;
   cursor: pointer;
} */
/* .btn {
   position: relative;
   background-color: #C4C4C4;
   top: 100px;
   cursor: pointer;
} */
/* .btn .create {
    background-color: #C4C4C4;
    cursor: pointer;
    position: absolute;
    top: 4px;
    right: 4px;
} */
.btn-small {
  background-color: #C4C4C4;
  position: absolute;
  top: 15px;
  right: 20px;
  cursor: pointer;  
}
.btn-large {
  position: absolute;
  left: 81.5%;
  top: 80%;
  background-color: #C4C4C4;
  cursor: pointer;
}
i.material-icons.create {
  text-align: center;
  cursor: pointer;
}

svg {
    position: absolute;
    left: 151px;
    top: 75px;
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);  
}
i.material-icons.search {
    position: absolute;
    left: 423px;
    top: 78px;
    font-size: 2.4em;
    color:rgba(79, 79, 79, 0.86)
}

i.material-icons.menu {
    position: absolute;
    right: 16%;
    top: 11.2%;
    font-size: 2.4em;
    color:rgba(79, 79, 79, 0.86);
    cursor: pointer;
}
/* .triangle-with-shadow {
    width: 88px;
    height: 88px;
    position: absolute;
    left: 85.5%;
    right: 7.25%;
    top: 13%;
    bottom: 93.16%;
    overflow: hidden;
    box-shadow: 0 16px 10px -17px rgba(0, 0, 0, 0.5);
    transform: rotate(180deg);
}
.triangle-with-shadow:after {
    content: "";
    position: absolute;
    width: 50px;
    height: 50px;
    background:slategrey;
    transform: rotate(45deg);
    top: 75px;
    left: 25px;
    box-shadow: -1px -1px 10px -2px rgba(0, 0, 0, 0.5);
    cursor: pointer;
} */
input.searchbar[type=text]:not(.browser-default) {
  position: absolute;
  left: 152px;
  top: 77px;
  width: 261px; 
  height: 33px;
  border-style: ridge;
  border-color:#C4C4C4;
}
button, input.searchbar, optgroup, select, textarea {
    font-family: Raleway;
    color: #FFFF;
}
</style>
