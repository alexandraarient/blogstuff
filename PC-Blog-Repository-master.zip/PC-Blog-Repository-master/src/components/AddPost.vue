<template>
    <div class="add-post container">
        <h2>Add New Blog Post:</h2>
        <form @submit.prevent="AddPost">
                <div class="field subject">
                    <label for="subject">Blog Post Subject:</label>
                    <input type="text" name="subject" v-model="subject">
                </div>
                <div class="field author">
                    <label for="author">Blog Post Author:</label>
                    <input type="text" name="author" v-model="author">
                </div>
                <div class="field date">
                    <label for="date">Date of Post:</label>
                    <input placeholder="November 11, 2011" type="text" name="date" v-model="date">
                </div>
                <div class="field time">
                    <label for="time">Time of Post:</label>
                    <input placeholder="11:00 AM" type="text" name="time" v-model="time">
                </div>
                <div class="field message">
                    <label for="message">Blog Post Message:</label>
                    <input type="text" name="message" v-model="message">
                </div>
                <br/>
        <div class="field center-align">
            <button class="btn-large depressed">Post</button>
        </div>
        <br/>
        <br/>
        </form>
    </div>
</template>

<script>
import db from '@/firebase/init'
import slugify from 'slugify'

export default {
    name: 'AddPost',
    data(){
        return{
            subject: null,
            author: null, 
            date: null,
            time: null,
            message: null,
            feedback: null,
            slug: null,
        }
    },
    methods: {
        AddPost(){
            if (this.subject){
                this.feedback = null
                //create a slug
                this.slug = slugify(this.subject, {
                    replacement: '-',
                    remove: /[$*_+~.()'"!\-:@]/g,
                    lower: true
                })
                db.collection('posts').add({
                    subject: this.subject,
                    author: this.author, 
                    date: this.date,
                    time: this.time,
                    message: this.message,
                    slug: this.slug
                }).then(() => {
                    this.$router.push({ name: 'Blog' })
                }).catch(err => {
                    console.log(err)
                })
            } else {
                this.feedback = 'You must enter a blog subject.'
            }
        }
    }
}
</script>

<style>
.add-post h2 {
  text-align: center;
  font-family: 'Raleway', sans-serif;
  font-size: 30px;
  color: rgba(79, 79, 79, 0.86);
  font-weight: 800;
}
.btn-large{
  text-align: center;
  background-color: #C4C4C4;
  font-family: 'Raleway', sans-serif;
}
button {
    background-color: #C4C4C4;
}
label {
    font-size: 16px;
    font-weight: 300;
    font-family: 'Raleway', sans-serif;
    color: rgba(79, 79, 79, 0.86);
}
input {
    font-family: 'Raleway', sans-serif;
}
.add-post{
    padding: 20px;
    max-width: 500px;
}
</style>